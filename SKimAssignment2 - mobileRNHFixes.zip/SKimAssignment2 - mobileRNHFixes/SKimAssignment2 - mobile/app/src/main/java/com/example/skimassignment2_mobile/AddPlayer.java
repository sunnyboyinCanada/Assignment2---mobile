package com.example.skimassignment2_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddPlayer<db> extends AppCompatActivity implements View.OnClickListener {


    private EditText oNameEdit;
    private Button oNameInsert;
    private PlayerDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_player);
        oNameEdit = (EditText) findViewById(R.id.AddPlayerName);
        oNameInsert = (Button) findViewById(R.id.BtnAddPlayer);
        oNameInsert.setOnClickListener(this);
        db = new PlayerDB(this);

    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.BtnAddPlayer){
//            if (oNameEdit.getText().toString() == null){
//                Toast toast = Toast.makeText(getApplicationContext(),"This can't be a player", Toast.LENGTH_SHORT);
//                toast.show();
//            }
                String sNewPlayer = oNameEdit.getText().toString();
                try {

                    db.insertPlayer(sNewPlayer);
                    oNameEdit.setText("");
                    finish();
                }
                catch (Exception e){
                    e.printStackTrace();
                }

            }
        }

    }

