package com.example.skimassignment2_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class ChoosePlayer1 extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

        Spinner spinner1;
        private PlayerDB db;
        String sPlayer1 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_player1);
        db = new PlayerDB(this);
        this.spinner1 = (Spinner) findViewById(R.id.player1);
        this.spinner1.setOnItemSelectedListener(this);
        updateDisplay();

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View v, int position, long l) {

        ArrayList<HashMapToString> data = db.getPlayers();
        ((Assignment2)this.getApplication()).player1 = data.get(position).get("name");

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    private void updateDisplay() {
        // create a List of Map<String, ?> objects
        ArrayList<HashMapToString> data = db.getPlayers();
        ArrayAdapter<HashMapToString> adapter =
                new ArrayAdapter<HashMapToString>(this,  android.R.layout.simple_spinner_dropdown_item, data);
        adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);

        spinner1.setAdapter(adapter);
    }
}
