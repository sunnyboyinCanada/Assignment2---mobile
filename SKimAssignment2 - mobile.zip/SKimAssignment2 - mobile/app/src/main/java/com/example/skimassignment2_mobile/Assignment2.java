package com.example.skimassignment2_mobile;

import android.app.Application;

public class Assignment2 extends Application {

    public String player1 = null;
    public String player2 = null;

}
